#! /bin/bash
python /home/core/speedychain/runner.py 10.0.2.10 9090 gw2 &
sleep 28
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 10 20 PBFT &
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw2 dv2 50 100 PBFT &
/home/core/speedychain/EVM/EVM &
#python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw2 -file /home/core/speedychain/EVM/gpsTracker2.csv