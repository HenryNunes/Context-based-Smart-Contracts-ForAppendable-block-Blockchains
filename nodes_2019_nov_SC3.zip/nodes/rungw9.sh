#! /bin/bash
python /home/core/speedychain/runner.py 10.0.2.10 9090 gw9 &
sleep 28
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 10 20 PBFT &
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw9 dv9 50 100 PBFT &
/home/core/speedychain/EVM/EVM &
#echo "good" & 
#python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw9 -file /home/core/speedychain/EVM/gpsTracker9.csv
