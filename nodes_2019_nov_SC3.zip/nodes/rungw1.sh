#! /bin/bash
python /home/core/speedychain/runner.py 10.0.2.10 9090 gw1 &
sleep 28
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 100 1000 PBFT &
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 100 100 PBFT &
/home/core/speedychain/EVM/EVM &
#echo "good" & 
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker01.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker2.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker3.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker4.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker5.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker6.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker7.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker8.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker9.csv
python /home/core/speedychain/src/tools/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker10.csv