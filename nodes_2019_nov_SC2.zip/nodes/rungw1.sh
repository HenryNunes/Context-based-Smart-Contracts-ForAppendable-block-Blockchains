#! /bin/bash
python /home/core/speedychain/runner.py 10.0.2.10 9090 gw1 &
sleep 28
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 100 1000 PBFT &
#python /home/core/speedychain/src/tools/DeviceSimulator.py 10.0.2.10 9090 gw1 dv1 100 100 PBFT &
/home/core/speedychain/EVM/EVM &
#echo "good" & 
#python /home/core/speedychain/src/tool/loader.py -ip 10.0.2.10 -port 9090 -gn gw1 -file /home/core/speedychain/EVM/gpsTracker1.csv